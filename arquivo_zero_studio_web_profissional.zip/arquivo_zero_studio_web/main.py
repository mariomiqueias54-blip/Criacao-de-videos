import os, uuid, asyncio, subprocess, tempfile, shutil, textwrap, json
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from PIL import Image, ImageDraw, ImageFont, ImageOps
import edge_tts

app=FastAPI(title='Arquivo Zero Studio')
BASE=Path(__file__).parent
OUTPUT=BASE/'outputs'; OUTPUT.mkdir(exist_ok=True)
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'

def cmd(args):
    p=subprocess.run(args,capture_output=True,text=True)
    if p.returncode: raise RuntimeError(p.stderr[-700:])
    return p.stdout

def wrap(draw,text,font,width):
    lines=[]; line=''
    for word in text.split():
        candidate=(line+' '+word).strip()
        if line and draw.textbbox((0,0),candidate,font=font)[2]>width:
            lines.append(line);line=word
        else: line=candidate
    if line: lines.append(line)
    return lines

def slide(path,img,title,subtitle,w,h):
    bg=Image.new('RGB',(w,h),(7,14,19))
    if img:
        im=ImageOps.fit(Image.open(img).convert('RGB'),(w,h))
        bg=Image.blend(im,bg,.48)
    d=ImageDraw.Draw(bg)
    d.rectangle((0,0,w,14),fill='#37d9a0')
    d.rectangle((0,h-int(h*.25),w,h),fill='#081017')
    large=ImageFont.truetype(FONT,max(28,int(w*.047)))
    small=ImageFont.truetype(FONT,max(22,int(w*.033)))
    d.text((int(w*.06),int(h*.065)),'ARQUIVO ZERO  /  STUDIO',font=small,fill='#37d9a0')
    y=int(h*.32)
    for line in wrap(d,title.upper(),large,int(w*.88))[:5]:
        d.text((int(w*.06),y),line,font=large,fill='white');y+=int(w*.064)
    y=int(h*.79)
    for line in wrap(d,subtitle,small,int(w*.88))[:4]:
        d.text((int(w*.06),y),line,font=small,fill='white');y+=int(w*.05)
    bg.save(path)

@app.get('/',response_class=HTMLResponse)
def home(): return (BASE/'index.html').read_text(encoding='utf-8')

@app.post('/api/roteiro')
async def roteiro(topic:str=Form(...), seconds:int=Form(60), style:str=Form('Sombrio e investigativo')):
    key=os.getenv('OPENAI_API_KEY')
    if not key: raise HTTPException(503,'Configure OPENAI_API_KEY no servidor para gerar roteiros com IA.')
    from openai import AsyncOpenAI
    client=AsyncOpenAI(api_key=key)
    prompt=f'Crie roteiro documental em português brasileiro para {seconds} segundos, tema: {topic}, estilo: {style}. Retorne JSON com title, script, caption, hook. Não invente fontes, fatos ou falas; destaque incertezas. Sem afirmações de notícias verificadas em tempo real. Gancho inicial forte sem clickbait enganoso.'
    try:
        r=await client.chat.completions.create(model=os.getenv('OPENAI_MODEL','gpt-4o-mini'),messages=[{'role':'user','content':prompt}],response_format={'type':'json_object'})
        return json.loads(r.choices[0].message.content)
    except Exception as e: raise HTTPException(502,'Falha na API de roteiro: '+str(e)[:150])

@app.post('/api/render')
async def render(title:str=Form(...),script:str=Form(...),format:str=Form('vertical'),voice:str=Form('pt-BR-AntonioNeural'),images:list[UploadFile]=File(default=[])):
    if not title.strip() or not script.strip(): raise HTTPException(400,'Informe título e narração.')
    if len(script)>5000: raise HTTPException(400,'Roteiro máximo de 5000 caracteres.')
    if len(images)>15: raise HTTPException(400,'Máximo de 15 imagens.')
    if voice not in ('pt-BR-AntonioNeural','pt-BR-FranciscaNeural'): raise HTTPException(400,'Voz inválida.')
    w,h=(1080,1920) if format=='vertical' else (1920,1080)
    job=uuid.uuid4().hex
    temp=Path(tempfile.mkdtemp(prefix='az_'))
    try:
        pics=[]
        for i,file in enumerate(images):
            if not file.filename: continue
            raw=await file.read(12_000_001)
            if len(raw)>12_000_000: raise HTTPException(400,'Imagem acima de 12 MB.')
            p=temp/f'img{i}.jpg'
            try:
                from io import BytesIO
                im=Image.open(BytesIO(raw));im.verify()
                im=Image.open(BytesIO(raw)).convert('RGB');im.thumbnail((2500,2500));im.save(p)
            except Exception: raise HTTPException(400,'Uma das imagens é inválida.')
            pics.append(p)
        audio=temp/'voice.mp3'
        await edge_tts.Communicate(script,voice).save(str(audio))
        probe=cmd(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(audio)])
        duration=float(probe.strip())
        words=script.split(); chunks=[' '.join(words[i:i+24]) for i in range(0,len(words),24)] or [script]
        per=duration/len(chunks)
        clips=[]
        for i,part in enumerate(chunks):
            pic=pics[i%len(pics)] if pics else None
            frame=temp/f'frame{i:03}.jpg';slide(frame,pic,title,part,w,h)
            clip=temp/f'clip{i:03}.mp4'
            cmd(['ffmpeg','-hide_banner','-loglevel','error','-y','-loop','1','-framerate','24','-i',str(frame),'-t',f'{per:.4f}','-vf',f'scale={w}:{h},format=yuv420p','-c:v','libx264','-preset','ultrafast','-crf','26','-r','24',str(clip)])
            clips.append(clip)
        concat=temp/'concat.txt';concat.write_text(''.join(f"file '{c}'\n" for c in clips))
        target=OUTPUT/f'{job}.mp4';audio_target=OUTPUT/f'{job}.mp3'
        cmd(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(concat),'-i',str(audio),'-c:v','copy','-c:a','aac','-b:a','160k','-shortest','-movflags','+faststart',str(target)])
        shutil.copy2(audio,audio_target)
        return {'video':f'/files/{job}.mp4','audio':f'/files/{job}.mp3','duration':round(duration,1),'resolution':f'{w}×{h}'}
    except HTTPException: raise
    except Exception as e: raise HTTPException(502,'Falha na renderização: '+str(e)[:200])
    finally: shutil.rmtree(temp,ignore_errors=True)

@app.get('/files/{filename}')
def files(filename:str):
    if not filename.endswith(('.mp4','.mp3')) or '/' in filename or '..' in filename: raise HTTPException(400)
    p=OUTPUT/filename
    if not p.exists(): raise HTTPException(404)
    return FileResponse(p,filename='arquivo_zero_'+filename)
