# Arquivo Zero Studio — versão Web

Site com geração de narração em português brasileiro via edge-tts e renderização MP4 Full HD via FFmpeg no servidor. Roteiro com OpenAI é opcional e requer OPENAI_API_KEY. Os vídeos são slides/imagens com voz, não filmagens geradas por IA.

## Publicar sem instalar nada no notebook
1. Crie um repositório privado no GitHub e envie os arquivos desta pasta (não envie o ZIP inteiro).
2. No Render.com, crie um **Web Service** conectado ao repositório, escolhendo **Docker** como runtime. Configure `OPENAI_API_KEY` como variável de ambiente se quiser geração de roteiro (a API pode cobrar por uso).
3. Escolha um plano com CPU, RAM e disco suficientes para renderizar Full HD; hospedagem gratuita pode não suportar vídeos grandes. Aguarde o deploy e abra o endereço HTTPS gerado no Chrome ou Edge.
4. O notebook não precisa instalar nada. Apenas um navegador e internet.

## Limitações de produção
- Não está hospedado ainda; é necessário publicar em uma plataforma de nuvem para ter link online.
- A narração edge-tts depende de um serviço online de terceiros, que pode falhar ou mudar disponibilidade.
- O render é síncrono e pode estourar o tempo-limite de serviços com pouca capacidade; para escala, usar fila de tarefas, armazenamento persistente, autenticação, limites de consumo e limpeza de arquivos.
- Arquivos em `outputs/` podem ser apagados em reinicializações de hospedagens com disco efêmero. Não use dados sensíveis; ainda não há login nem isolamento por usuário.
- Imagens precisam ser fornecidas pelo usuário; verifique direitos de uso e sinalize reconstruções sintéticas.

## Desenvolvimento local opcional
`pip install -r requirements.txt`, instale ffmpeg, depois `uvicorn main:app --reload`. A instalação local é só para desenvolvimento, não para quem usar o site publicado.
